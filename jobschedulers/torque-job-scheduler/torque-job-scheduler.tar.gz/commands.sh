sed -i -e 's/$pbsserver shakuntala.local/$pbsserver shakuntala.local/g' /var/spool/torque/mom_priv/config
